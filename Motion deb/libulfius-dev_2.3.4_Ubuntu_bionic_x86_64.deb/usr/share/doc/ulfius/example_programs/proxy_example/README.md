# Proxy example

Run a simple proxy application that will redirect all calls to `PROXY_DEST` address

## Compile and run

```bash
$ make test
```

## Usage:

Open in your browser the url [http://localhost:7799/](http://localhost:7799/) to access the url specified by `PROXY_DEST` in `proxy.c`
